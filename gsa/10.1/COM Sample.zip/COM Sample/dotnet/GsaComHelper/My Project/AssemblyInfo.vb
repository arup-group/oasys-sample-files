﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("DotNetHelpers")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Oasys")> 
<Assembly: AssemblyProduct("GSA")>
<Assembly: AssemblyCopyright("Oasys 1996-2017 Oasys Ltd.")>
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("afe98ad6-9a8d-4654-95e7-cc3d4f7ad7c1")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 
<Assembly: CLSCompliant(False)>
<Assembly: AssemblyVersion("9.0.0.10")>
<Assembly: AssemblyFileVersion("9.0.0.10")>
