﻿
Namespace Interop.gsa_8_6
    Class Results

    End Class
End Namespace
